• Combat
      + Aimbot
            - Enabled
            - Aim Bone
            - Aim Mode
            - Check FOV
            - Draw Fov
            - Dynamic Fov
            - FOV Size (10 - 500)
            - Smoothing (5 - 10)
            - FOV Color Picker
      + Silent Aim
            - Enabled
            - Aim Bone
            - Check FOV
            - Draw Fov
            - Dynamic Fov
            - FOV Size (10 - 500)
            - FOV Color Picker
      + Weapons
            - No Recoil
            - Infinite Ammo
            - Rapid Fire

• Visual
      + ESP
            - Tracers
            - Skeleton
            - 3D Boxes
            - 2D Boxes
            - Info
            - Nametags
            - Background Color Picker
            - Teammate Color Picker
            - Enemy Color Picker
            - Bot Color Picker
      + FOV Changer
            - Enabled
            - Amount (20 - 150)

• Movement
      + Speed
            - Enabled
            - Amount (1 - 10)
      + Fly
            - Enabled
      + BHop
            - Enabled

• Exploits
      + Player
            - Godmode
            - Instant Land
            - Infinite Materials
            - Anti Freeze
      + Gameplay
            - Leave Game
            - Auto Play
      + Locker
            - Unlock Emotes
            - Unlock Stickers
            - Skin Changer
            - Pickaxe Changer
      + Game
            - Force Win
            - Kill All
            - Freeze Players
            - Destroy Buildings
            - Open Crates
            - Building Spam
            - Rig Spam
            - Instant Break
      + Fun
            - Add 10k Fake Gold
            - Add 10k Fake Gems
            - Loadout Level Changer

• Settings
      + Config Manager
            - Save
            - Delete
      + Interface
            - Watermark
            - Watermark Time Type
      + Config Loader
